import React from "react";
import NavBar from "./NavBar";
function AboutPage(){


return(

<div>

<NavBar/>

<h1>about</h1>

</div>

)

}

export default AboutPage;