import React from "react";
import NavBar from "./NavBar";
function PricesPage(){


return(

<div>
<NavBar/>
<h1>prices</h1>

</div>

)

}

export default PricesPage;