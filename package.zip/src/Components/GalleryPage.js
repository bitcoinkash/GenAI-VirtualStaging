import React from "react";
import NavBar from "./NavBar";
function GalleryPage(){


return(

<div>

<NavBar/>

<h1>gallery</h1>

</div>

)

}

export default GalleryPage;